<?php namespace Scinventario\Events;

abstract class Event {

	//

}
