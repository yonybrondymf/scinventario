<?php namespace Scinventario\Commands;

abstract class Command {

	//

}
