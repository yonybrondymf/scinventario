
    <div class="form-group">
        {!! Form::label('name', 'Nombre : ', array('class' => 'col-md-4 control-label')) !!}
        <div class="col-md-4">
            {!! Form::text('name', null,array('class' => 'form-control', 'placeholder' => 'Escriba algun Nombre')) !!}
        </div>
    </div>
    

